# Zara AI — Telegram Voice Chat AI & Music Assistant

Zara is a conversational voice AI and music assistant built for Telegram Voice Chats, powered by Google Gemini, Telethon, PyTgCalls, and Aiogram 3.

## Features
- Natural Voice Chat Conversations (Hindi, Hinglish, English)
- Aaru Music Integration
- Telegram Stars (XTR) Subscription Management
- MongoDB Persistence & Robust Background Scheduler
- Railway / Docker Ready
