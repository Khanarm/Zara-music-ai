# telegram/subscription.py

import logging
import re
from datetime import datetime, timezone

from aiogram import Router, F
from aiogram.filters import CommandStart
from aiogram.types import (
    Message,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)

from config import (
    PREMIUM_DURATION_DAYS,
    PREMIUM_PLAN_NAME,
    PREMIUM_STARS_PRICE,
    SUBSCRIPTIONS_ENABLED,
)

from database.mongodb import get_collection

from payments.stars import (
    create_subscription_invoice,
)

from payments.subscriptions import (
    get_group_subscription,
    is_group_subscription_active,
    get_user_group_subscriptions,
    activate_paid_group,
)

logger = logging.getLogger(__name__)

router = Router(
    name="zara_subscription"
)


# ============================================================
# HELPERS
# ============================================================

GROUP_TYPES = {
    "group",
    "supergroup",
}


def is_group(message: Message) -> bool:
    return message.chat.type in GROUP_TYPES


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def normalize_group_id(value: str) -> int | None:
    """
    Validate Telegram group ID.

    Telegram supergroup IDs normally look like:
        -1001234567890
    """

    value = value.strip()

    if not re.fullmatch(
        r"-100\d{5,20}",
        value,
    ):
        return None

    try:
        return int(value)
    except ValueError:
        return None


def subscribe_keyboard(
    bot_username: str | None = None,
) -> InlineKeyboardMarkup:

    if bot_username:
        url = (
            f"https://t.me/{bot_username}"
            "?start=subscribe"
        )
    else:
        url = "https://t.me/"

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="⭐ Subscribe",
                    url=url,
                )
            ]
        ]
    )


def start_keyboard() -> InlineKeyboardMarkup:

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="📢 Updates",
                    callback_data="zara_updates",
                ),
                InlineKeyboardButton(
                    text="❓ Help",
                    callback_data="zara_help",
                ),
            ],
            [
                InlineKeyboardButton(
                    text="⭐ SUBSCRIBE",
                    callback_data="zara_subscribe",
                )
            ],
        ]
    )


def help_keyboard() -> InlineKeyboardMarkup:

    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="⭐ Subscribe",
                    callback_data="zara_subscribe",
                )
            ],
            [
                InlineKeyboardButton(
                    text="⬅️ Back",
                    callback_data="zara_home",
                )
            ],
        ]
    )


# ============================================================
# BOT USERNAME
# ============================================================

async def get_bot_username(
    message: Message,
) -> str | None:

    try:
        me = await message.bot.get_me()

        return getattr(
            me,
            "username",
            None,
        )

    except Exception:
        logger.exception(
            "Unable to get bot username."
        )

        return None


# ============================================================
# GROUP SUBSCRIPTION GUARD
# ============================================================

@router.message(
    F.chat.type.in_(GROUP_TYPES),
    F.text.startswith("/"),
)
async def group_command_subscription_guard(
    message: Message,
) -> None:
    """
    Check subscription whenever a user sends a command
    inside a group.

    If the current group is not subscribed by this user,
    show the Subscribe button.

    If subscription is active, this handler does nothing
    intentionally. The actual command handlers will be
    registered after this router / through the main event
    router.
    """

    if not message.from_user:
        return

    if not SUBSCRIPTIONS_ENABLED:
        return

    user_id = int(
        message.from_user.id
    )

    group_id = int(
        message.chat.id
    )

    try:
        active = await is_group_subscription_active(
            user_id=user_id,
            group_id=group_id,
        )

    except Exception:
        logger.exception(
            "Group subscription check failed."
        )

        await message.answer(
            "⚠️ I couldn't check the subscription "
            "for this group right now."
        )

        return

    if active:
        # IMPORTANT:
        #
        # This handler cannot pass the update to another
        # handler after consuming it.
        #
        # Therefore actual command handlers should perform
        # their own subscription check or this guard should
        # later be converted into middleware.
        #
        # We intentionally do nothing here for now.
        return

    bot_username = await get_bot_username(
        message
    )

    await message.answer(
        "⭐ <b>Zara Premium is required</b>\n\n"
        "Zara is not currently activated for this group.\n\n"
        "Subscribe to activate Zara in this group.",
        reply_markup=subscribe_keyboard(
            bot_username
        ),
    )


# ============================================================
# /START
# ============================================================

@router.message(
    CommandStart()
)
async def start_command(
    message: Message,
) -> None:

    if not message.from_user:
        return

    name = (
        message.from_user.first_name
        or "there"
    )

    await message.answer(
        f"👋 <b>Welcome {name}!</b>\n\n"
        "I am <b>Zara AI</b>, an AI voice assistant "
        "for Telegram groups.\n\n"
        "🎙️ Talk with Zara\n"
        "🎵 Play music in Voice Chat\n"
        "🧠 Chat with AI\n"
        "👩 Natural female AI voice\n\n"
        "Add Zara to your group and activate a "
        "subscription to use her.",
        reply_markup=start_keyboard(),
    )


# ============================================================
# SUBSCRIBE BUTTON
# ============================================================

@router.callback_query(
    F.data == "zara_subscribe"
)
async def subscribe_callback(
    callback,
) -> None:

    if not callback.from_user:
        return

    try:
        await callback.answer()

        await create_subscription_invoice(
            bot=callback.bot,
            user_id=callback.from_user.id,
        )

    except Exception:
        logger.exception(
            "Failed to create subscription invoice."
        )

        try:
            await callback.message.answer(
                "⚠️ I couldn't create the payment "
                "invoice right now. Please try again."
            )
        except Exception:
            pass


# ============================================================
# DEEP-LINK SUBSCRIBE
# ============================================================

@router.message(
    CommandStart(
        deep_link=True
    )
)
async def subscribe_deep_link(
    message: Message,
) -> None:
    """
    /start subscribe

    Used when the user taps Subscribe from a group.
    """

    if not message.from_user:
        return

    try:
        await create_subscription_invoice(
            bot=message.bot,
            user_id=message.from_user.id,
        )

    except Exception:
        logger.exception(
            "Deep-link subscription invoice failed."
        )

        await message.answer(
            "⚠️ Unable to create the subscription "
            "payment right now."
        )


# ============================================================
# GROUP ID RECEIVER
# ============================================================

@router.message(
    F.chat.type == "private",
    F.text.regexp(
        re.compile(
            r"^-100\d{5,20}$"
        )
    ),
)
async def group_id_message(
    message: Message,
) -> None:
    """
    Receive the Group ID after a successful payment.

    The newest paid and unbound payment of the user
    is attached to this group.
    """

    if not message.from_user:
        return

    user_id = int(
        message.from_user.id
    )

    group_id = normalize_group_id(
        message.text or ""
    )

    if group_id is None:
        await message.answer(
            "❌ Invalid Group ID.\n\n"
            "Please send a valid Telegram group ID, "
            "for example:\n"
            "<code>-1001234567890</code>"
        )
        return

    try:
        payments = get_collection(
            "payments"
        )

        # Find newest successful payment that has not
        # already been attached to a group.
        cursor = payments.find(
            {
                "user_id": user_id,
                "status": "paid",
                "group_id": {
                    "$exists": False
                },
            }
        ).sort(
            "paid_at",
            -1,
        ).limit(1)

        pending_payments = await cursor.to_list(
            length=1
        )

        if not pending_payments:

            await message.answer(
                "❌ I couldn't find an unused paid "
                "subscription.\n\n"
                "Please purchase the subscription first."
            )
            return

        payment = pending_payments[0]

        payment_id = payment.get(
            "payment_id"
        )

        if not payment_id:
            await message.answer(
                "⚠️ Payment record is incomplete. "
                "Please contact the owner."
            )
            return

        # ----------------------------------------------------
        # Verify the bot is actually in the group.
        # ----------------------------------------------------

        try:
            bot_member = await message.bot.get_chat_member(
                chat_id=group_id,
                user_id=(await message.bot.get_me()).id,
            )

        except Exception:

            await message.answer(
                "❌ I couldn't access this group.\n\n"
                "Make sure Zara's bot is already added "
                "to the group and try again."
            )
            return

        if bot_member.status in {
            "left",
            "kicked",
        }:

            await message.answer(
                "❌ Zara is not in that group.\n\n"
                "Please add Zara to the group first."
            )
            return

        # ----------------------------------------------------
        # Verify user is a member of the group.
        # ----------------------------------------------------

        try:
            user_member = await message.bot.get_chat_member(
                chat_id=group_id,
                user_id=user_id,
            )

        except Exception:

            await message.answer(
                "❌ I couldn't verify that you are "
                "a member of this group."
            )
            return

        if user_member.status in {
            "left",
            "kicked",
        }:

            await message.answer(
                "❌ You are not a member of that group.\n\n"
                "Please join the group first."
            )
            return

        # ----------------------------------------------------
        # Check existing subscription.
        # ----------------------------------------------------

        existing = await get_group_subscription(
            user_id=user_id,
            group_id=group_id,
        )

        if existing:

            active = await is_group_subscription_active(
                user_id=user_id,
                group_id=group_id,
            )

            if active:

                await message.answer(
                    "ℹ️ Zara is already active in this group."
                )
                return

        # ----------------------------------------------------
        # Bind payment to EXACTLY this group.
        # ----------------------------------------------------

        subscription = await activate_paid_group(
            payment_id=payment_id,
            user_id=user_id,
            group_id=group_id,
        )

        # ----------------------------------------------------
        # Mark payment as bound.
        # ----------------------------------------------------

        await payments.update_one(
            {
                "payment_id": payment_id,
            },
            {
                "$set": {
                    "group_id": group_id,
                    "group_bound_at": utc_now(),
                    "subscription_id": str(
                        subscription.get("_id")
                    ),
                }
            },
        )

        group_title = str(
            group_id
        )

        try:
            chat = await message.bot.get_chat(
                group_id
            )

            group_title = (
                chat.title
                or group_title
            )

        except Exception:
            pass

        await message.answer(
            "✅ <b>Zara activated successfully!</b>\n\n"
            f"👥 Group: <b>{group_title}</b>\n"
            f"⭐ Plan: <b>{PREMIUM_PLAN_NAME}</b>\n"
            f"💳 Price: <b>{PREMIUM_STARS_PRICE} Stars</b>\n"
            f"📅 Duration: <b>{PREMIUM_DURATION_DAYS} days</b>\n\n"
            "Zara is now ready to use in this group. 🎙️"
        )

    except ValueError as exc:

        logger.warning(
            "Group activation rejected: %s",
            exc,
        )

        await message.answer(
            f"❌ {str(exc)}"
        )

    except Exception:

        logger.exception(
            "Group ID activation failed."
        )

        await message.answer(
            "⚠️ I couldn't activate Zara for this group.\n\n"
            "Please try again or contact the owner."
        )


# ============================================================
# /MYPLAN
# ============================================================

@router.message(
    F.chat.type == "private",
    F.text.startswith("/myplan"),
)
async def myplan_private(
    message: Message,
) -> None:

    if not message.from_user:
        return

    user_id = int(
        message.from_user.id
    )

    try:
        subscriptions = await get_user_group_subscriptions(
            user_id=user_id,
            include_expired=True,
        )

        if not subscriptions:

            await message.answer(
                "⭐ <b>Your Zara Plan</b>\n\n"
                "You don't have any group subscription yet.\n\n"
                "Subscribe to activate Zara in a group.",
                reply_markup=help_keyboard(),
            )
            return

        lines = [
            "⭐ <b>Your Zara Subscriptions</b>",
            "",
        ]

        for index, subscription in enumerate(
            subscriptions,
            start=1,
        ):

            group_id = subscription.get(
                "group_id"
            )

            status = subscription.get(
                "status",
                "unknown",
            )

            expires_at = subscription.get(
                "expires_at"
            )

            if status == "active" and expires_at:

                if expires_at.tzinfo is None:
                    expires_at = expires_at.replace(
                        tzinfo=timezone.utc
                    )

                if expires_at > utc_now():

                    remaining = (
                        expires_at
                        - utc_now()
                    ).days

                    status_text = (
                        f"✅ Active\n"
                        f"Expires: "
                        f"<b>{expires_at.strftime('%d %B %Y')}</b>\n"
                        f"Days remaining: "
                        f"<b>{max(1, remaining)}</b>"
                    )

                else:

                    status_text = (
                        "❌ Expired"
                    )

            else:

                status_text = (
                    "❌ Expired"
                    if status == "expired"
                    else f"⚠️ {status.title()}"
                )

            group_title = str(
                group_id
            )

            try:
                chat = await message.bot.get_chat(
                    group_id
                )

                group_title = (
                    chat.title
                    or group_title
                )

            except Exception:
                pass

            lines.extend(
                [
                    f"<b>{index}. {group_title}</b>",
                    f"Group ID: <code>{group_id}</code>",
                    f"Plan: <b>{subscription.get('plan', PREMIUM_PLAN_NAME)}</b>",
                    status_text,
                    "",
                ]
            )

        await message.answer(
            "\n".join(lines),
            reply_markup=help_keyboard(),
        )

    except Exception:

        logger.exception(
            "Private /myplan failed."
        )

        await message.answer(
            "⚠️ Unable to load your subscriptions."
        )


@router.message(
    F.chat.type.in_(GROUP_TYPES),
    F.text.startswith("/myplan"),
)
async def myplan_group(
    message: Message,
) -> None:

    if not message.from_user:
        return

    user_id = int(
        message.from_user.id
    )

    group_id = int(
        message.chat.id
    )

    try:

        subscription = await get_group_subscription(
            user_id=user_id,
            group_id=group_id,
        )

        if not subscription:

            bot_username = await get_bot_username(
                message
            )

            await message.answer(
                "❌ <b>Zara is not subscribed "
                "for this group.</b>\n\n"
                "Subscribe to activate Zara here.",
                reply_markup=subscribe_keyboard(
                    bot_username
                ),
            )
            return

        active = await is_group_subscription_active(
            user_id=user_id,
            group_id=group_id,
        )

        expires_at = subscription.get(
            "expires_at"
        )

        if expires_at and expires_at.tzinfo is None:
            expires_at = expires_at.replace(
                tzinfo=timezone.utc
            )

        if active and expires_at:

            remaining = (
                expires_at
                - utc_now()
            ).days

            status_text = "✅ Active"

            expiry_text = (
                f"{expires_at.strftime('%d %B %Y')}"
            )

            days_text = str(
                max(1, remaining)
            )

        else:

            status_text = "❌ Expired"
            expiry_text = "Expired"
            days_text = "0"

        await message.answer(
            "⭐ <b>Zara Plan</b>\n\n"
            f"Group: <b>{message.chat.title}</b>\n"
            f"Plan: <b>{subscription.get('plan', PREMIUM_PLAN_NAME)}</b>\n"
            f"Price: <b>{subscription.get('stars', PREMIUM_STARS_PRICE)} Stars</b>\n"
            f"Status: <b>{status_text}</b>\n"
            f"Expires: <b>{expiry_text}</b>\n"
            f"Days remaining: <b>{days_text}</b>"
        )

    except Exception:

        logger.exception(
            "Group /myplan failed."
        )

        await message.answer(
            "⚠️ Unable to load this group's subscription."
        )


# ============================================================
# CALLBACKS
# ============================================================

@router.callback_query(F.data == "zara_home")
async def zara_home_callback(callback):
    try:
        await callback.answer("Zara is ready.")
    except Exception:
        pass
