# telegram/events.py

import logging
from typing import Optional

from aiogram import Router, F
from aiogram.types import Message

from telegram.client import get_user_client

from ai.brain import chat
from ai.intent import (
    detect_intent,
    is_music_intent,
    MUSIC_PLAY,
    MUSIC_SEARCH,
    MUSIC_PAUSE,
    MUSIC_RESUME,
    MUSIC_SKIP,
    MUSIC_STOP,
    MUSIC_QUEUE,
    MUSIC_REMOVE,
)

from database.users import (
    get_user,
    create_user,
)

from database.groups import (
    get_group,
)

from payments.subscriptions import (
    is_group_subscription_active,
)

from config import OWNER_ID


logger = logging.getLogger(__name__)

router = Router()


# ============================================================
# USER HELPERS
# ============================================================

async def ensure_user(
    message: Message,
) -> Optional[dict]:
    """
    Make sure Telegram user exists in MongoDB.
    """

    if not message.from_user:
        return None

    user_id = message.from_user.id

    try:
        user = await get_user(
            user_id
        )

        if user:
            return user

        # Create user if not found.
        user = await create_user(
            user_id=user_id,
            username=message.from_user.username,
            first_name=message.from_user.first_name,
            last_name=message.from_user.last_name,
        )

        return user

    except Exception:
        logger.exception(
            "Failed to ensure user %s",
            user_id,
        )

        return None


# ============================================================
# GROUP HELPERS
# ============================================================

def is_group_message(
    message: Message,
) -> bool:
    """
    Check whether message came from a group.
    """

    if not message.chat:
        return False

    return message.chat.type in {
        "group",
        "supergroup",
    }


async def get_group_settings(
    chat_id: int,
) -> Optional[dict]:
    """
    Get group configuration from database.
    """

    try:
        return await get_group(
            chat_id
        )

    except Exception:
        logger.exception(
            "Failed to get group settings: %s",
            chat_id,
        )

        return None


# ============================================================
# MENTION DETECTION
# ============================================================

def bot_is_mentioned(
    message: Message,
) -> bool:
    """
    Detect whether Zara was mentioned in the message.
    """

    text = (
        message.text
        or message.caption
        or ""
    ).lower()

    if not text:
        return False

    entities = (
        message.entities
        or message.caption_entities
        or []
    )

    for entity in entities:

        if entity.type == "mention":

            try:
                username = text[
                    entity.offset:
                    entity.offset
                    + entity.length
                ]

                if username.startswith(
                    "@"
                ):
                    return True

            except Exception:
                continue

    return False


def is_reply_to_bot(
    message: Message,
) -> bool:
    """
    Check whether the user replied to Zara.
    """

    if not message.reply_to_message:
        return False

    replied = (
        message.reply_to_message
    )

    if not replied.from_user:
        return False

    # This will be checked against bot identity
    # by the handler when possible.
    return replied.from_user.is_bot


# ============================================================
# GROUP AI PERMISSION
# ============================================================

def should_answer_group(
    message: Message,
    group_settings: Optional[dict],
) -> bool:
    """
    Decide whether Zara should answer in a group.
    """

    # No group configuration yet:
    # allow normal operation.
    if not group_settings:
        return True

    if group_settings.get(
        "ai_enabled",
        True,
    ) is False:
        return False

    reply_to_all = group_settings.get(
        "reply_to_all",
        False,
    )

    if reply_to_all:
        return True

    # Explicit mention.
    if bot_is_mentioned(
        message
    ):
        return True

    # Reply to a bot message.
    if is_reply_to_bot(
        message
    ):
        return True

    return False


# ============================================================
# GET REPLY CONTEXT
# ============================================================

async def get_reply_context(
    message: Message,
) -> Optional[str]:
    """
    Get text of the message being replied to.
    """

    reply = message.reply_to_message

    if not reply:
        return None

    return (
        reply.text
        or reply.caption
        or None
    )


# ============================================================
# CLEAN MENTION
# ============================================================

def clean_message_text(
    message: Message,
) -> str:
    """
    Remove common bot mention from message text.
    """

    text = (
        message.text
        or message.caption
        or ""
    ).strip()

    if not text:
        return ""

    # Remove @username tokens.
    words = text.split()

    cleaned = []

    for word in words:

        if word.startswith("@"):
            continue

        cleaned.append(word)

    return " ".join(
        cleaned
    ).strip()


# ============================================================
# MUSIC HANDLER PLACEHOLDER
# ============================================================

async def handle_music_intent(message: Message, intent: str) -> bool:
    # Music requests are intentionally routed through the voice command
    # adapter in voice/music_commands.py. Text commands are not used for
    # normal group music control.
    return False


# ============================================================
# AI MESSAGE HANDLER
# ============================================================

@router.message(
    F.text
)
async def handle_text_message(
    message: Message,
) -> None:
    """
    Main Telegram text message handler.
    """

    if not message.from_user:
        return

    text = clean_message_text(
        message
    )

    if not text:
        return

    user_id = message.from_user.id

    # --------------------------------------------------------
    # Ensure user exists
    # --------------------------------------------------------

    user = await ensure_user(
        message
    )

    # --------------------------------------------------------
    # Group checks
    # --------------------------------------------------------

    group_settings = None

    if is_group_message(
        message
    ):

        group_settings = (
            await get_group_settings(
                message.chat.id
            )
        )

        if not should_answer_group(
            message,
            group_settings,
        ):
            return

    # --------------------------------------------------------
    # GROUP SUBSCRIPTION
    # --------------------------------------------------------

    if is_group_message(message):

        try:
            subscription_active = (
                await is_group_subscription_active(
                    user_id=message.from_user.id,
                    group_id=message.chat.id,
                )
            )

        except Exception:
            logger.exception(
                "Failed to check group subscription."
            )

            await message.answer(
                "⚠️ I couldn't check Zara's subscription "
                "for this group right now."
            )

            return

        if not subscription_active:

            try:
                bot_me = await message.bot.get_me()
                bot_username = bot_me.username
            except Exception:
                bot_username = None

            if bot_username:
                subscribe_url = (
                    f"https://t.me/{bot_username}"
                    "?start=subscribe"
                )
            else:
                subscribe_url = "https://t.me/"

            from aiogram.types import (
                InlineKeyboardMarkup,
                InlineKeyboardButton,
            )

            keyboard = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(
                            text="⭐ Subscribe",
                            url=subscribe_url,
                        )
                    ]
                ]
            )

            await message.answer(
                "⭐ <b>Zara Premium is required</b>\n\n"
                "This group does not have an active "
                "Zara subscription.\n\n"
                "Subscribe to activate Zara in this group.",
                reply_markup=keyboard,
            )

            return    
    # --------------------------------------------------------
    # User information
    # --------------------------------------------------------

    username = (
        message.from_user.username
    )

    first_name = (
        message.from_user.first_name
    )

    last_name = (
        message.from_user.last_name
    )

    is_premium = False

    if user:
        is_premium = bool(
            user.get(
                "is_premium",
                False,
            )
        )

    # --------------------------------------------------------
    # Group information
    # --------------------------------------------------------

    chat_id = message.chat.id

    group_title = None

    ai_enabled = True
    reply_to_all = False
    reply_to_mentions = True

    if group_settings:

        group_title = group_settings.get(
            "title"
        )

        ai_enabled = group_settings.get(
            "ai_enabled",
            True,
        )

        reply_to_all = group_settings.get(
            "reply_to_all",
            False,
        )

        reply_to_mentions = group_settings.get(
            "reply_to_mentions",
            True,
        )

    # --------------------------------------------------------
    # Reply context
    # --------------------------------------------------------

    reply_context = await get_reply_context(
        message
    )

    # --------------------------------------------------------
    # Intent
    # --------------------------------------------------------

    try:

        intent_result = await detect_intent(
            text=text
        )

    except Exception:

        logger.exception(
            "Intent detection failed."
        )

        return

    intent = intent_result.intent

    # --------------------------------------------------------
    # Music
    # --------------------------------------------------------

    if is_music_intent(
        intent
    ):

        handled = await handle_music_intent(
            message=message,
            intent=intent,
        )

        if handled:
            return

    # --------------------------------------------------------
    # Typing indicator
    # --------------------------------------------------------

    try:

        await message.bot.send_chat_action(
            chat_id=message.chat.id,
            action="typing",
        )

    except Exception:
        pass

    # --------------------------------------------------------
    # Generate Zara response
    # --------------------------------------------------------

    try:

        response = await chat(
            user_id=user_id,
            message=text,
            chat_id=chat_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            is_premium=is_premium,
            group_title=group_title,
            group_language=(
                "Hinglish"
            ),
            ai_enabled=ai_enabled,
            reply_to_all=reply_to_all,
            reply_to_mentions=reply_to_mentions,
            reply_to_message=reply_context,
        )

    except Exception:

        logger.exception(
            "Zara AI failed for user %s",
            user_id,
        )

        try:
            await message.answer(
                "Sorry bhai, abhi thoda technical issue aa gaya. Thodi der baad try karo."
            )
        except Exception:
            pass

        return

    if not response:
        return

    # --------------------------------------------------------
    # Send response
    # --------------------------------------------------------

    try:

        await message.answer(
            response,
            reply_to_message_id=message.message_id,
        )

    except Exception:

        logger.exception(
            "Failed to send Zara response."
        )


# ============================================================
# VOICE MESSAGE HANDLER
# ============================================================

@router.message(
    F.voice
)
async def handle_voice_message(
    message: Message,
) -> None:
    """
    Voice messages will be connected to the STT system.

    Actual processing will be implemented in:
        voice/receiver.py
        voice/processor.py
        voice/stt.py
    """

    if not message.from_user:
        return

    await message.answer(
        "🎙️ Voice processing module abhi connect ho raha hai."
    )


# ============================================================
# AUDIO MESSAGE HANDLER
# ============================================================

@router.message(
    F.audio
)
async def handle_audio_message(
    message: Message,
) -> None:
    """
    Audio messages will be processed by the voice/audio system.
    """

    if not message.from_user:
        return

    await message.answer(
        "🎵 Audio processing module abhi connect ho raha hai."
    )


# ============================================================
# PHOTO / DOCUMENT FALLBACK
# ============================================================

@router.message(
    F.photo
)
async def handle_photo_message(
    message: Message,
) -> None:
    """
    Placeholder for future vision support.
    """

    if not message.from_user:
        return

    caption = (
        message.caption
        or ""
    ).strip()

    if not caption:
        return

    try:

        response = await chat(
            user_id=message.from_user.id,
            message=caption,
            chat_id=message.chat.id,
            username=(
                message.from_user.username
            ),
            first_name=(
                message.from_user.first_name
            ),
            last_name=(
                message.from_user.last_name
            ),
        )

        if response:
            await message.answer(
                response
            )

    except Exception:
        logger.exception(
            "Photo caption processing failed."
        )


# ============================================================
# REGISTER ROUTER
# ============================================================

def register_handlers(
    dispatcher,
) -> None:
    """
    Register Zara event handlers.
    """

    dispatcher.include_router(
        router
    )

    logger.info(
        "Telegram event handlers registered."
)
