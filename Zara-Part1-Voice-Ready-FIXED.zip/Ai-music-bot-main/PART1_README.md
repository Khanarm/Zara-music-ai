# Zara Part 1 — VC Music & Video

This build uses the reference project's playback architecture without copying its source code:

YouTube search -> yt-dlp -> FFmpeg/PyTgCalls MediaStream -> Telegram Voice Chat.

## Features
- `/join` — admin/owner enables Zara music mode for the group.
- `/end` — admin/owner stops playback and clears the queue.
- `/use` — Zara owner chooses `All User` or `Admin` request mode.
- FIFO queue: the first requester plays first; later requests wait in order.
- Group announcements identify requester, current track and queue position.
- Current-track controls are restricted to the requester or a group admin/owner.
- Audio and video downloads are supported through yt-dlp.
- Audio/video playback uses PyTgCalls MediaStream.
- Loop, skip, stop, pause/resume hooks and automatic next-track scheduling are included.
- `voice/music_commands.py` is the single bridge for VC speech-to-text: once the VC STT receiver has a transcript, call `handle_voice_transcript(...)`.

## Environment
Copy `.env.example` to `.env` and fill the existing Zara variables. Never commit `.env` or Telegram sessions/cookies.

Set `YOUTUBE_COOKIES_FILE` only if your YouTube setup requires cookies.

## Important runtime note
PyTgCalls is used here for Voice Chat playback. Participant-audio capture/transcription is intentionally isolated behind `voice/music_commands.py`; the reference playback project does not itself provide a complete participant speech-to-text pipeline. A VC STT provider/receiver must feed transcripts into that bridge. No fake speech capture is claimed by this build.
