import logging, os
from typing import Optional
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream
try:
 from pytgcalls.exceptions import GroupCallNotFoundError
except ImportError:
 GroupCallNotFoundError=Exception
logger=logging.getLogger(__name__)
class AudioStream:
 def __init__(self,client,calls:PyTgCalls): self.client=client; self.calls=calls; self.current_streams={}; self.paused_streams={}
 async def start(self): await self.calls.start()
 async def play(self,chat_id,audio_path,*,video=False,join_muted=False):
  if not os.path.isfile(audio_path): return False
  try:
   if chat_id in self.current_streams: await self.stop(chat_id)
   stream=MediaStream(audio_path)
   await self.calls.play(int(chat_id),stream)
   self.current_streams[int(chat_id)]=audio_path; self.paused_streams.pop(int(chat_id),None); return True
  except GroupCallNotFoundError:return False
  except Exception: logger.exception('stream play failed'); return False
 async def stop(self,chat_id):
  try: await self.calls.leave_call(int(chat_id)); self.current_streams.pop(int(chat_id),None); self.paused_streams.pop(int(chat_id),None); return True
  except GroupCallNotFoundError:return False
  except Exception: logger.exception('stream stop failed'); return False
 async def leave(self,chat_id):return await self.stop(chat_id)
 def is_playing(self,chat_id):return int(chat_id) in self.current_streams
 def get_current_stream(self,chat_id):return self.current_streams.get(int(chat_id))
 async def pause(self,chat_id):
  fn=getattr(self.calls,'pause',None)
  if not fn:return False
  try: await fn(int(chat_id)); self.paused_streams[int(chat_id)]=self.current_streams.pop(int(chat_id),None); return True
  except Exception:return False
 async def resume(self,chat_id):
  fn=getattr(self.calls,'resume',None)
  if not fn:return False
  try: await fn(int(chat_id)); p=self.paused_streams.pop(int(chat_id),None); 
  except Exception:return False
  if p:self.current_streams[int(chat_id)]=p
  return True
 async def change_stream(self,chat_id,path,video=False): await self.stop(chat_id); return await self.play(chat_id,path,video=video)
 async def cleanup(self):
  for cid in list(self.current_streams):
   try: await self.stop(cid)
   except: pass
