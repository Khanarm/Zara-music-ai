# database/payments.py

import logging
from datetime import datetime, timezone
from typing import Any, Optional

from database.mongodb import payments as payments_collection

logger = logging.getLogger(__name__)


# ============================================================
# TIME HELPER
# ============================================================

def utc_now() -> datetime:
    return datetime.now(timezone.utc)


# ============================================================
# PAYMENT DOCUMENT
# ============================================================

def build_payment_document(
    payment_id: str,
    user_id: int,
    group_id: int,
    amount: int,
    currency: str,
    telegram_payment_charge_id: Optional[str] = None,
    invoice_payload: Optional[str] = None,
) -> dict[str, Any]:
    """
    Build a Telegram Stars payment document.

    Payment records are immutable financial records.
    """

    now = utc_now()

    return {
        "payment_id": payment_id,
        "user_id": int(user_id),
        "group_id": int(group_id),

        "amount": int(amount),
        "currency": currency,

        "invoice_payload": invoice_payload,

        "telegram_payment_charge_id": (
            telegram_payment_charge_id
        ),

        "status": "completed",

        "subscription_activated": False,

        "created_at": now,
        "updated_at": now,
    }


# ============================================================
# PAYMENT LOOKUP
# ============================================================

async def get_payment(
    payment_id: str,
) -> Optional[dict[str, Any]]:
    """
    Get payment by internal payment ID.
    """

    if not payment_id:
        return None

    return await payments_collection().find_one(
        {
            "payment_id": str(payment_id),
        }
    )


async def get_payment_by_charge_id(
    charge_id: str,
) -> Optional[dict[str, Any]]:
    """
    Get payment by Telegram's provider charge ID.

    This is important for payment idempotency.
    """

    if not charge_id:
        return None

    return await payments_collection().find_one(
        {
            "telegram_payment_charge_id": str(
                charge_id
            ),
        }
    )


# ============================================================
# CHECK PAYMENT EXISTS
# ============================================================

async def payment_exists(
    payment_id: str,
) -> bool:
    """
    Check whether a payment already exists.
    """

    payment = await get_payment(
        payment_id
    )

    return payment is not None


async def charge_exists(
    charge_id: str,
) -> bool:
    """
    Check whether a Telegram charge was already recorded.
    """

    payment = await get_payment_by_charge_id(
        charge_id
    )

    return payment is not None


# ============================================================
# RECORD PAYMENT
# ============================================================

async def record_payment(
    payment_id: str,
    user_id: int,
    group_id: int,
    amount: int,
    currency: str,
    telegram_payment_charge_id: Optional[str] = None,
    invoice_payload: Optional[str] = None,
) -> bool:
    """
    Record a successfully verified Telegram Stars payment.

    Returns:
        True  -> newly recorded
        False -> payment already exists
    """

    payment_id = str(payment_id)

    existing = await get_payment(
        payment_id
    )

    if existing:
        logger.info(
            "Payment already exists: %s",
            payment_id,
        )

        return False

    if telegram_payment_charge_id:
        existing_charge = (
            await get_payment_by_charge_id(
                telegram_payment_charge_id
            )
        )

        if existing_charge:
            logger.warning(
                "Duplicate Telegram charge rejected: %s",
                telegram_payment_charge_id,
            )

            return False

    if int(amount) <= 0:
        raise ValueError(
            "Payment amount must be greater than zero."
        )

    if not currency:
        raise ValueError(
            "Payment currency cannot be empty."
        )

    document = build_payment_document(
        payment_id=payment_id,
        user_id=user_id,
        group_id=group_id,
        amount=amount,
        currency=currency,
        telegram_payment_charge_id=(
            telegram_payment_charge_id
        ),
        invoice_payload=invoice_payload,
    )

    try:
        await payments_collection().insert_one(
            document
        )

    except Exception as exc:
        # MongoDB unique indexes protect against
        # race-condition duplicates.
        logger.exception(
            "Failed to record payment %s",
            payment_id,
        )

        # If another worker inserted the same payment
        # simultaneously, treat it as already recorded.
        existing = await get_payment(
            payment_id
        )

        if existing:
            return False

        raise exc

    logger.info(
        "Recorded Telegram payment: %s | user=%s | group=%s | amount=%s %s",
        payment_id,
        user_id,
        group_id,
        amount,
        currency,
    )

    return True


# ============================================================
# MARK SUBSCRIPTION ACTIVATED
# ============================================================

async def mark_subscription_activated(
    payment_id: str,
) -> bool:
    """
    Mark that the payment has been consumed to activate
    a subscription.

    This prevents the same payment from activating a
    subscription more than once.
    """

    result = await payments_collection().update_one(
        {
            "payment_id": str(payment_id),
            "subscription_activated": False,
        },
        {
            "$set": {
                "subscription_activated": True,
                "updated_at": utc_now(),
            }
        },
    )

    return result.modified_count > 0


# ============================================================
# CHECK ACTIVATION STATE
# ============================================================

async def is_subscription_activated(
    payment_id: str,
) -> bool:
    """
    Return True if the payment has already activated a
    subscription.
    """

    payment = await get_payment(
        payment_id
    )

    if not payment:
        return False

    return bool(
        payment.get(
            "subscription_activated",
            False,
        )
    )


# ============================================================
# PAYMENT STATUS
# ============================================================

async def update_payment_status(
    payment_id: str,
    status: str,
) -> bool:
    """
    Update payment status.

    Allowed values:

        pending
        completed
        failed
        refunded
    """

    status = str(status).strip().lower()

    allowed = {
        "pending",
        "completed",
        "failed",
        "refunded",
    }

    if status not in allowed:
        raise ValueError(
            f"Invalid payment status: {status}"
        )

    result = await payments_collection().update_one(
        {
            "payment_id": str(payment_id),
        },
        {
            "$set": {
                "status": status,
                "updated_at": utc_now(),
            }
        },
    )

    return result.modified_count > 0


# ============================================================
# USER PAYMENTS
# ============================================================

async def get_user_payments(
    user_id: int,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """
    Return payment history for a user.
    """

    limit = max(
        1,
        min(int(limit), 500),
    )

    cursor = (
        payments_collection()
        .find(
            {
                "user_id": int(user_id),
            }
        )
        .sort(
            "created_at",
            -1,
        )
        .limit(limit)
    )

    return await cursor.to_list(
        length=limit
    )


# ============================================================
# GROUP PAYMENTS
# ============================================================

async def get_group_payments(
    group_id: int,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """
    Return payment history for a group.
    """

    limit = max(
        1,
        min(int(limit), 500),
    )

    cursor = (
        payments_collection()
        .find(
            {
                "group_id": int(group_id),
            }
        )
        .sort(
            "created_at",
            -1,
        )
        .limit(limit)
    )

    return await cursor.to_list(
        length=limit
    )


# ============================================================
# USER + GROUP PAYMENTS
# ============================================================

async def get_user_group_payments(
    user_id: int,
    group_id: int,
    limit: int = 50,
) -> list[dict[str, Any]]:
    """
    Return payment history for a specific user/group
    relationship.
    """

    limit = max(
        1,
        min(int(limit), 500),
    )

    cursor = (
        payments_collection()
        .find(
            {
                "user_id": int(user_id),
                "group_id": int(group_id),
            }
        )
        .sort(
            "created_at",
            -1,
        )
        .limit(limit)
    )

    return await cursor.to_list(
        length=limit
    )


# ============================================================
# LATEST PAYMENT
# ============================================================

async def get_latest_payment(
    user_id: int,
    group_id: Optional[int] = None,
) -> Optional[dict[str, Any]]:
    """
    Return the latest completed payment.

    If group_id is supplied, only payments for that group
    are considered.
    """

    query: dict[str, Any] = {
        "user_id": int(user_id),
        "status": "completed",
    }

    if group_id is not None:
        query["group_id"] = int(group_id)

    return await (
        payments_collection()
        .find_one(
            query,
            sort=[
                (
                    "created_at",
                    -1,
                )
            ],
        )
    )


# ============================================================
# PAYMENT COUNT
# ============================================================

async def count_user_payments(
    user_id: int,
) -> int:
    """
    Count all payments made by a user.
    """

    return await payments_collection().count_documents(
        {
            "user_id": int(user_id),
        }
    )


async def count_group_payments(
    group_id: int,
) -> int:
    """
    Count all payments for a group.
    """

    return await payments_collection().count_documents(
        {
            "group_id": int(group_id),
        }
    )


# ============================================================
# TOTAL USER SPEND
# ============================================================

async def get_user_total_spend(
    user_id: int,
) -> int:
    """
    Calculate total completed Stars paid by a user.

    Only XTR/Telegram Stars payments should normally be
    stored here.
    """

    pipeline = [
        {
            "$match": {
                "user_id": int(user_id),
                "status": "completed",
                "currency": "XTR",
            }
        },
        {
            "$group": {
                "_id": None,
                "total": {
                    "$sum": "$amount",
                },
            }
        },
    ]

    result = await (
        payments_collection()
        .aggregate(pipeline)
        .to_list(length=1)
    )

    if not result:
        return 0

    return int(
        result[0].get(
            "total",
            0,
        )
    )


# ============================================================
# TOTAL GROUP REVENUE
# ============================================================

async def get_group_total_revenue(
    group_id: int,
) -> int:
    """
    Calculate total completed Stars paid for a group.
    """

    pipeline = [
        {
            "$match": {
                "group_id": int(group_id),
                "status": "completed",
                "currency": "XTR",
            }
        },
        {
            "$group": {
                "_id": None,
                "total": {
                    "$sum": "$amount",
                },
            }
        },
    ]

    result = await (
        payments_collection()
        .aggregate(pipeline)
        .to_list(length=1)
    )

    if not result:
        return 0

    return int(
        result[0].get(
            "total",
            0,
        )
    )


# ============================================================
# VERIFY PAYMENT RECORD
# ============================================================

async def verify_payment_record(
    payment_id: str,
    user_id: int,
    group_id: int,
    amount: int,
    currency: str = "XTR",
) -> bool:
    """
    Verify that an already-recorded payment matches the
    expected transaction details.

    This is useful for defensive checks before activating
    a subscription.
    """

    payment = await get_payment(
        payment_id
    )

    if not payment:
        return False

    if int(
        payment.get(
            "user_id",
            0,
        )
    ) != int(user_id):
        return False

    if int(
        payment.get(
            "group_id",
            0,
        )
    ) != int(group_id):
        return False

    if int(
        payment.get(
            "amount",
            0,
        )
    ) != int(amount):
        return False

    if str(
        payment.get(
            "currency",
            "",
        )
    ).upper() != str(currency).upper():
        return False

    return True


# ============================================================
# PAYMENT ACTIVATION LOCK
# ============================================================

async def claim_payment_for_subscription(
    payment_id: str,
) -> bool:
    """
    Atomically claim a payment for subscription activation.

    Only the first caller receives True.

    This is the most important idempotency protection:
    if two update handlers/processes receive the same payment,
    only one can consume it.
    """

    result = await payments_collection().update_one(
        {
            "payment_id": str(payment_id),
            "status": "completed",
            "subscription_activated": False,
        },
        {
            "$set": {
                "subscription_activated": True,
                "updated_at": utc_now(),
            }
        },
    )

    return result.modified_count == 1


# ============================================================
# REFUND MARKER
# ============================================================

async def mark_payment_refunded(
    payment_id: str,
    reason: Optional[str] = None,
) -> bool:
    """
    Mark a payment as refunded.

    This does not automatically revoke a subscription.
    Subscription changes must be handled by the subscription
    service.
    """

    update: dict[str, Any] = {
        "status": "refunded",
        "refunded_at": utc_now(),
        "updated_at": utc_now(),
    }

    if reason:
        update["refund_reason"] = reason

    result = await payments_collection().update_one(
        {
            "payment_id": str(payment_id),
        },
        {
            "$set": update,
        },
    )

    return result.modified_count > 0
