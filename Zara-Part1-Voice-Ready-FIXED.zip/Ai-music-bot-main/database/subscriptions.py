# database/subscriptions.py

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

from database.mongodb import subscriptions as subscriptions_collection

logger = logging.getLogger(__name__)


# ============================================================
# TIME HELPERS
# ============================================================

def utc_now() -> datetime:
    """Return the current UTC datetime."""
    return datetime.now(timezone.utc)


def ensure_utc(value: datetime) -> datetime:
    """
    Convert a datetime to timezone-aware UTC.

    MongoDB normally returns timezone-aware datetimes when the
    Motor client is configured accordingly, but this helper
    safely handles naive datetimes as well.
    """
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)

    return value.astimezone(timezone.utc)


# ============================================================
# SUBSCRIPTION DOCUMENT
# ============================================================

def build_subscription_document(
    user_id: int,
    group_id: int,
    duration_days: int = 30,
    payment_id: Optional[str] = None,
) -> dict[str, Any]:
    """
    Build a new subscription document.

    The subscription starts immediately and expires after
    duration_days.
    """

    user_id = int(user_id)
    group_id = int(group_id)
    duration_days = int(duration_days)

    if duration_days <= 0:
        raise ValueError(
            "Subscription duration must be greater than zero."
        )

    now = utc_now()

    return {
        "user_id": user_id,
        "group_id": group_id,

        "status": "active",

        "started_at": now,
        "expires_at": now + timedelta(days=duration_days),

        "payment_id": (
            str(payment_id)
            if payment_id
            else None
        ),

        "reminder_sent": False,
        "reminder_sent_at": None,

        "expired_at": None,

        "created_at": now,
        "updated_at": now,
    }


# ============================================================
# GET SUBSCRIPTION
# ============================================================

async def get_subscription(
    user_id: int,
    group_id: int,
) -> Optional[dict[str, Any]]:
    """
    Get a subscription by user_id + group_id.
    """

    return await subscriptions_collection().find_one(
        {
            "user_id": int(user_id),
            "group_id": int(group_id),
        }
    )


# ============================================================
# GET BY PAYMENT ID
# ============================================================

async def get_subscription_by_payment(
    payment_id: str,
) -> Optional[dict[str, Any]]:
    """
    Find a subscription associated with a payment ID.
    """

    if not payment_id:
        return None

    return await subscriptions_collection().find_one(
        {
            "payment_id": str(payment_id),
        }
    )


# ============================================================
# CREATE SUBSCRIPTION
# ============================================================

async def create_subscription(
    user_id: int,
    group_id: int,
    duration_days: int = 30,
    payment_id: Optional[str] = None,
) -> Optional[dict[str, Any]]:
    """
    Create a new subscription.

    If a subscription already exists for the same
    user_id + group_id, the existing document is returned.

    Normal renewals should use activate_subscription().
    """

    user_id = int(user_id)
    group_id = int(group_id)
    duration_days = int(duration_days)

    if duration_days <= 0:
        raise ValueError(
            "Subscription duration must be greater than zero."
        )

    existing = await get_subscription(
        user_id,
        group_id,
    )

    if existing is not None:
        return existing

    document = build_subscription_document(
        user_id=user_id,
        group_id=group_id,
        duration_days=duration_days,
        payment_id=payment_id,
    )

    try:
        await subscriptions_collection().insert_one(
            document
        )
    except Exception:
        # A unique MongoDB index may have prevented a race.
        existing = await get_subscription(
            user_id,
            group_id,
        )

        if existing is not None:
            return existing

        raise

    logger.info(
        "Created subscription: user=%s group=%s",
        user_id,
        group_id,
    )

    return document


# ============================================================
# ACTIVATE / RENEW FROM VERIFIED PAYMENT
# ============================================================

async def activate_subscription(
    user_id: int,
    group_id: int,
    payment_id: str,
    duration_days: int = 30,
) -> Optional[dict[str, Any]]:
    """
    Activate or renew a subscription after a payment has
    already been verified.

    Rules:

    1. No existing subscription:
       now + duration

    2. Existing active subscription:
       current expiry + duration

    3. Existing expired subscription:
       now + duration

    IMPORTANT:
    Payment verification and payment idempotency should be
    handled by the payment layer before calling this function.
    """

    user_id = int(user_id)
    group_id = int(group_id)
    duration_days = int(duration_days)

    payment_id = str(payment_id).strip()

    if not payment_id:
        raise ValueError(
            "payment_id cannot be empty."
        )

    if duration_days <= 0:
        raise ValueError(
            "Subscription duration must be greater than zero."
        )

    now = utc_now()

    existing = await get_subscription(
        user_id,
        group_id,
    )

    if existing is None:
        document = {
            "user_id": user_id,
            "group_id": group_id,

            "status": "active",

            "started_at": now,
            "expires_at": now + timedelta(
                days=duration_days
            ),

            "payment_id": payment_id,

            "reminder_sent": False,
            "reminder_sent_at": None,

            "expired_at": None,

            "created_at": now,
            "updated_at": now,
        }

        try:
            await subscriptions_collection().insert_one(
                document
            )
        except Exception:
            existing = await get_subscription(
                user_id,
                group_id,
            )

            if existing is not None:
                return existing

            raise

        logger.info(
            "Activated new subscription: "
            "user=%s group=%s payment=%s",
            user_id,
            group_id,
            payment_id,
        )

        return document

    current_expiry = existing.get(
        "expires_at"
    )

    if current_expiry:
        current_expiry = ensure_utc(
            current_expiry
        )

    if (
        existing.get("status") == "active"
        and current_expiry is not None
        and current_expiry > now
    ):
        # Renewal before expiry.
        new_start = existing.get(
            "started_at",
            now,
        )

        if isinstance(new_start, datetime):
            new_start = ensure_utc(
                new_start
            )

        new_expiry = current_expiry + timedelta(
            days=duration_days
        )

    else:
        # Subscription expired.
        new_start = now
        new_expiry = now + timedelta(
            days=duration_days
        )

    result = await subscriptions_collection().update_one(
        {
            "user_id": user_id,
            "group_id": group_id,
        },
        {
            "$set": {
                "status": "active",
                "started_at": new_start,
                "expires_at": new_expiry,

                "payment_id": payment_id,

                "reminder_sent": False,
                "reminder_sent_at": None,

                "expired_at": None,

                "updated_at": now,
            }
        },
    )

    if result.matched_count == 0:
        return None

    updated = await get_subscription(
        user_id,
        group_id,
    )

    logger.info(
        "Activated/renewed subscription: "
        "user=%s group=%s payment=%s",
        user_id,
        group_id,
        payment_id,
    )

    return updated


# ============================================================
# RENEW SUBSCRIPTION
# ============================================================

async def renew_subscription(
    user_id: int,
    group_id: int,
    payment_id: str,
    duration_days: int = 30,
) -> Optional[dict[str, Any]]:
    """
    Renew an existing subscription.

    The renewal logic is handled by activate_subscription().
    """

    return await activate_subscription(
        user_id=user_id,
        group_id=group_id,
        payment_id=payment_id,
        duration_days=duration_days,
    )


# ============================================================
# ACTIVE CHECK
# ============================================================

async def is_subscription_active(
    user_id: int,
    group_id: int,
) -> bool:
    """
    Check whether a subscription is currently active.

    The expiry timestamp is checked directly, so access is
    denied even if the scheduler has not yet marked it expired.
    """

    subscription = await get_subscription(
        user_id,
        group_id,
    )

    if subscription is None:
        return False

    if subscription.get("status") != "active":
        return False

    expires_at = subscription.get(
        "expires_at"
    )

    if not isinstance(expires_at, datetime):
        return False

    return ensure_utc(expires_at) > utc_now()


# ============================================================
# GET ACTIVE SUBSCRIPTION
# ============================================================

async def get_active_subscription(
    user_id: int,
    group_id: int,
) -> Optional[dict[str, Any]]:
    """
    Return the active subscription or None.
    """

    subscription = await get_subscription(
        user_id,
        group_id,
    )

    if subscription is None:
        return None

    if subscription.get("status") != "active":
        return None

    expires_at = subscription.get(
        "expires_at"
    )

    if not isinstance(expires_at, datetime):
        return None

    if ensure_utc(expires_at) <= utc_now():
        return None

    return subscription


# ============================================================
# EXPIRE ONE SUBSCRIPTION
# ============================================================

async def expire_subscription(
    user_id: int,
    group_id: int,
) -> bool:
    """
    Mark one active subscription as expired.
    """

    now = utc_now()

    result = await subscriptions_collection().update_one(
        {
            "user_id": int(user_id),
            "group_id": int(group_id),
            "status": "active",
            "expires_at": {
                "$lte": now,
            },
        },
        {
            "$set": {
                "status": "expired",
                "expired_at": now,
                "updated_at": now,
            }
        },
    )

    if result.modified_count > 0:
        logger.info(
            "Expired subscription: user=%s group=%s",
            user_id,
            group_id,
        )
        return True

    return False


# ============================================================
# EXPIRE DUE SUBSCRIPTIONS
# ============================================================

async def expire_due_subscriptions(
    limit: int = 500,
) -> int:
    """
    Mark expired subscriptions as expired.

    Uses MongoDB update_many for efficient bulk processing.
    """

    now = utc_now()

    limit = max(
        1,
        min(int(limit), 5000),
    )

    cursor = (
        subscriptions_collection()
        .find(
            {
                "status": "active",
                "expires_at": {
                    "$lte": now,
                },
            },
            {
                "_id": 1,
            },
        )
        .limit(limit)
    )

    documents = await cursor.to_list(
        length=limit
    )

    if not documents:
        return 0

    ids = [
        document["_id"]
        for document in documents
        if "_id" in document
    ]

    if not ids:
        return 0

    result = await subscriptions_collection().update_many(
        {
            "_id": {
                "$in": ids,
            },
            "status": "active",
        },
        {
            "$set": {
                "status": "expired",
                "expired_at": now,
                "updated_at": now,
            }
        },
    )

    if result.modified_count > 0:
        logger.info(
            "Expired %s subscription(s).",
            result.modified_count,
        )

    return int(
        result.modified_count
    )


# ============================================================
# REMINDER CHECK
# ============================================================

async def needs_expiry_reminder(
    user_id: int,
    group_id: int,
    hours: int = 24,
) -> bool:
    """
    Check whether a subscription needs an expiry reminder.
    """

    hours = int(hours)

    if hours <= 0:
        return False

    subscription = await get_subscription(
        user_id,
        group_id,
    )

    if subscription is None:
        return False

    if subscription.get("status") != "active":
        return False

    if subscription.get(
        "reminder_sent",
        False,
    ):
        return False

    expires_at = subscription.get(
        "expires_at"
    )

    if not isinstance(expires_at, datetime):
        return False

    expires_at = ensure_utc(
        expires_at
    )

    now = utc_now()

    return (
        expires_at > now
        and expires_at <= now + timedelta(
            hours=hours
        )
    )


# ============================================================
# MARK REMINDER SENT
# ============================================================

async def mark_reminder_sent(
    user_id: int,
    group_id: int,
) -> bool:
    """
    Atomically mark the reminder as sent.

    Only one worker can successfully change False -> True.
    """

    now = utc_now()

    result = await subscriptions_collection().update_one(
        {
            "user_id": int(user_id),
            "group_id": int(group_id),
            "status": "active",
            "reminder_sent": False,
        },
        {
            "$set": {
                "reminder_sent": True,
                "reminder_sent_at": now,
                "updated_at": now,
            }
        },
    )

    return result.modified_count == 1


# ============================================================
# GET SUBSCRIPTIONS NEEDING REMINDER
# ============================================================

async def get_subscriptions_needing_reminder(
    hours: int = 24,
    limit: int = 500,
) -> list[dict[str, Any]]:
    """
    Return active subscriptions expiring within the reminder
    window.
    """

    hours = int(hours)
    limit = max(
        1,
        min(int(limit), 1000),
    )

    if hours <= 0:
        return []

    now = utc_now()

    reminder_until = now + timedelta(
        hours=hours
    )

    cursor = (
        subscriptions_collection()
        .find(
            {
                "status": "active",
                "reminder_sent": False,
                "expires_at": {
                    "$gt": now,
                    "$lte": reminder_until,
                },
            }
        )
        .sort(
            "expires_at",
            1,
        )
        .limit(limit)
    )

    return await cursor.to_list(
        length=limit
    )


# ============================================================
# GET USER SUBSCRIPTIONS
# ============================================================

async def get_user_subscriptions(
    user_id: int,
    active_only: bool = False,
    limit: int = 100,
) -> list[dict[str, Any]]:
    """
    Return subscriptions belonging to a user.
    """

    limit = max(
        1,
        min(int(limit), 500),
    )

    query: dict[str, Any] = {
        "user_id": int(user_id),
    }

    if active_only:
        query["status"] = "active"

    cursor = (
        subscriptions_collection()
        .find(query)
        .sort(
            "expires_at",
            -1,
        )
        .limit(limit)
    )

    return await cursor.to_list(
        length=limit
    )


# ============================================================
# GET GROUP SUBSCRIPTIONS
# ============================================================

async def get_group_subscriptions(
    group_id: int,
    active_only: bool = False,
    limit: int = 100,
) -> list[dict[str, Any]]:
    """
    Return subscriptions belonging to a group.
    """

    limit = max(
        1,
        min(int(limit), 500),
    )

    query: dict[str, Any] = {
        "group_id": int(group_id),
    }

    if active_only:
        query["status"] = "active"

    cursor = (
        subscriptions_collection()
        .find(query)
        .sort(
            "expires_at",
            -1,
        )
        .limit(limit)
    )

    return await cursor.to_list(
        length=limit
    )


# ============================================================
# GET EXPIRING SUBSCRIPTIONS
# ============================================================

async def get_expiring_subscriptions(
    hours: int = 24,
    limit: int = 500,
) -> list[dict[str, Any]]:
    """
    Return active subscriptions expiring within the specified
    number of hours.
    """

    hours = int(hours)
    limit = max(
        1,
        min(int(limit), 1000),
    )

    if hours <= 0:
        return []

    now = utc_now()

    expires_before = now + timedelta(
        hours=hours
    )

    cursor = (
        subscriptions_collection()
        .find(
            {
                "status": "active",
                "expires_at": {
                    "$gt": now,
                    "$lte": expires_before,
                },
            }
        )
        .sort(
            "expires_at",
            1,
        )
        .limit(limit)
    )

    return await cursor.to_list(
        length=limit
    )


# ============================================================
# DAYS REMAINING
# ============================================================

async def get_days_remaining(
    user_id: int,
    group_id: int,
) -> Optional[float]:
    """
    Return approximate remaining subscription days.

    Returns None if no subscription exists.
    """

    subscription = await get_subscription(
        user_id,
        group_id,
    )

    if subscription is None:
        return None

    expires_at = subscription.get(
        "expires_at"
    )

    if not isinstance(expires_at, datetime):
        return None

    remaining_seconds = (
        ensure_utc(expires_at) - utc_now()
    ).total_seconds()

    return max(
        0.0,
        remaining_seconds / 86400,
    )


# ============================================================
# SUBSCRIPTION STATUS
# ============================================================

async def get_subscription_status(
    user_id: int,
    group_id: int,
) -> str:
    """
    Return:

        active
        expired
        not_found
    """

    subscription = await get_subscription(
        user_id,
        group_id,
    )

    if subscription is None:
        return "not_found"

    if subscription.get("status") != "active":
        return "expired"

    expires_at = subscription.get(
        "expires_at"
    )

    if not isinstance(expires_at, datetime):
        return "expired"

    if ensure_utc(expires_at) <= utc_now():
        return "expired"

    return "active"


# ============================================================
# ACTIVE SUBSCRIPTION COUNT
# ============================================================

async def count_active_subscriptions() -> int:
    """
    Count subscriptions whose stored status is active.

    Scheduler should periodically expire due subscriptions.
    """

    return await subscriptions_collection().count_documents(
        {
            "status": "active",
        }
    )


# ============================================================
# USER ACTIVE SUBSCRIPTION COUNT
# ============================================================

async def count_user_active_subscriptions(
    user_id: int,
) -> int:
    """
    Count active subscriptions for a user.
    """

    return await subscriptions_collection().count_documents(
        {
            "user_id": int(user_id),
            "status": "active",
        }
    )


# ============================================================
# DELETE SUBSCRIPTION
# ============================================================

async def delete_subscription(
    user_id: int,
    group_id: int,
) -> bool:
    """
    Delete a subscription document.

    Normally subscriptions should be expired rather than
    deleted so historical records remain available.
    """

    result = await subscriptions_collection().delete_one(
        {
            "user_id": int(user_id),
            "group_id": int(group_id),
        }
    )

    if result.deleted_count > 0:
        logger.info(
            "Deleted subscription: user=%s group=%s",
            user_id,
            group_id,
        )
        return True

    return False


# ============================================================
# SUBSCRIPTION SUMMARY
# ============================================================

async def get_subscription_summary(
    user_id: int,
    group_id: int,
) -> dict[str, Any]:
    """
    Return a convenient subscription summary for UI/messages.
    """

    subscription = await get_subscription(
        user_id,
        group_id,
    )

    if subscription is None:
        return {
            "exists": False,
            "active": False,
            "status": "not_found",
            "user_id": int(user_id),
            "group_id": int(group_id),
            "expires_at": None,
            "days_remaining": None,
            "payment_id": None,
        }

    expires_at = subscription.get(
        "expires_at"
    )

    active = False
    days_remaining: Optional[float] = None

    if (
        subscription.get("status") == "active"
        and isinstance(expires_at, datetime)
    ):
        expires_at = ensure_utc(
            expires_at
        )

        remaining = (
            expires_at - utc_now()
        ).total_seconds()

        if remaining > 0:
            active = True
            days_remaining = remaining / 86400

    return {
        "exists": True,
        "active": active,
        "status": (
            "active"
            if active
            else "expired"
        ),
        "user_id": int(user_id),
        "group_id": int(group_id),
        "started_at": subscription.get(
            "started_at"
        ),
        "expires_at": subscription.get(
            "expires_at"
        ),
        "days_remaining": days_remaining,
        "payment_id": subscription.get(
            "payment_id"
        ),
        "reminder_sent": bool(
            subscription.get(
                "reminder_sent",
                False,
            )
        ),
    }


# ============================================================
# RESET REMINDER
# ============================================================

async def reset_reminder(
    user_id: int,
    group_id: int,
) -> bool:
    """
    Reset the expiry reminder flag.

    Useful when a subscription is renewed manually or when
    administrative recovery is required.
    """

    result = await subscriptions_collection().update_one(
        {
            "user_id": int(user_id),
            "group_id": int(group_id),
        },
        {
            "$set": {
                "reminder_sent": False,
                "reminder_sent_at": None,
                "updated_at": utc_now(),
            }
        },
    )

    return result.modified_count > 0


# ============================================================
# SUBSCRIPTION EXISTS
# ============================================================

async def subscription_exists(
    user_id: int,
    group_id: int,
) -> bool:
    """
    Check whether a subscription document exists.
    """

    document = await subscriptions_collection().find_one(
        {
            "user_id": int(user_id),
            "group_id": int(group_id),
        },
        {
            "_id": 1,
        },
    )

    return document is not None
