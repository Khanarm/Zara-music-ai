import logging
from typing import Optional
logger=logging.getLogger(__name__)
_service=None
def configure_music_service(service):
    global _service; _service=service
def get_music_service(): return _service
async def handle_voice_transcript(chat_id:int,user_id:int,user_name:str,text:str):
    """Call this from the VC STT receiver after it transcribes a participant."""
    if _service is None: return False,'Music service unavailable.'
    try: return await _service.handle_text(chat_id,user_id,user_name,text)
    except Exception: logger.exception('voice music command failed'); return False,'Music command failed.'
