# payments/subscriptions.py

import logging
from datetime import datetime, timedelta, timezone
from typing import Optional

from database.mongodb import get_collection

from config import (
    PREMIUM_DURATION_DAYS,
    PREMIUM_PLAN_NAME,
    PREMIUM_STARS_PRICE,
)

logger = logging.getLogger(__name__)


# ============================================================
# HELPERS
# ============================================================

def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def normalize_user_id(user_id: int) -> int:
    return int(user_id)


def normalize_group_id(group_id: int) -> int:
    return int(group_id)


def group_subscriptions():
    """
    Group-specific Zara subscriptions.

    We intentionally use a separate collection because the
    existing database/subscriptions.py is user-level.
    """

    return get_collection("group_subscriptions")


# ============================================================
# DATABASE INDEXES
# ============================================================

async def initialize_subscription_indexes() -> None:
    """
    Create indexes for group-specific subscriptions.

    Safe to call multiple times.
    """

    collection = group_subscriptions()

    await collection.create_index(
        [
            ("user_id", 1),
            ("group_id", 1),
        ],
        unique=True,
        name="group_subscription_user_group_unique",
    )

    await collection.create_index(
        [
            ("group_id", 1),
            ("status", 1),
        ],
        name="group_subscription_group_status",
    )

    await collection.create_index(
        [
            ("user_id", 1),
            ("status", 1),
        ],
        name="group_subscription_user_status",
    )

    await collection.create_index(
        [
            ("expires_at", 1),
        ],
        name="group_subscription_expiry",
    )

    await collection.create_index(
        [
            ("payment_id", 1),
        ],
        unique=True,
        sparse=True,
        name="group_subscription_payment_unique",
    )

    logger.info(
        "Group subscription indexes initialized."
    )


# ============================================================
# CREATE / ACTIVATE
# ============================================================

async def create_group_subscription(
    user_id: int,
    group_id: int,
    payment_id: str,
    plan: str = PREMIUM_PLAN_NAME,
    duration_days: int = PREMIUM_DURATION_DAYS,
    stars: int = PREMIUM_STARS_PRICE,
) -> dict:
    """
    Activate a paid Zara subscription for exactly one group.

    One payment can activate only one group.
    """

    user_id = normalize_user_id(user_id)
    group_id = normalize_group_id(group_id)

    duration_days = max(
        1,
        int(duration_days),
    )

    stars = int(stars)

    now = utc_now()

    collection = group_subscriptions()

    existing = await collection.find_one(
        {
            "user_id": user_id,
            "group_id": group_id,
        }
    )

    existing_expiry: Optional[datetime] = None

    if existing:
        existing_expiry = existing.get(
            "expires_at"
        )

        if existing_expiry:
            if existing_expiry.tzinfo is None:
                existing_expiry = existing_expiry.replace(
                    tzinfo=timezone.utc
                )
            else:
                existing_expiry = existing_expiry.astimezone(
                    timezone.utc
                )

    # If the same group already has an active subscription,
    # extend it instead of losing remaining time.
    if existing_expiry and existing_expiry > now:
        start_date = existing_expiry
    else:
        start_date = now

    expires_at = (
        start_date
        + timedelta(days=duration_days)
    )

    document = {
        "user_id": user_id,
        "group_id": group_id,
        "plan": plan,
        "status": "active",
        "stars": stars,
        "payment_id": payment_id,
        "started_at": (
            existing.get("started_at", now)
            if existing and existing_expiry
            and existing_expiry > now
            else now
        ),
        "expires_at": expires_at,
        "updated_at": now,
    }

    if not existing:
        document["created_at"] = now

    await collection.update_one(
        {
            "user_id": user_id,
            "group_id": group_id,
        },
        {
            "$set": document,
        },
        upsert=True,
    )

    logger.info(
        "Zara group subscription activated: "
        "user=%s group=%s expires=%s",
        user_id,
        group_id,
        expires_at,
    )

    return await get_group_subscription(
        user_id,
        group_id,
    )


# ============================================================
# GET GROUP SUBSCRIPTION
# ============================================================

async def get_group_subscription(
    user_id: int,
    group_id: int,
) -> Optional[dict]:
    """
    Get subscription for one user in one specific group.
    """

    return await group_subscriptions().find_one(
        {
            "user_id": normalize_user_id(user_id),
            "group_id": normalize_group_id(group_id),
        }
    )


# ============================================================
# ACTIVE CHECK
# ============================================================

async def is_group_subscription_active(
    user_id: int,
    group_id: int,
) -> bool:
    """
    Check whether Zara is active for this exact user/group pair.
    """

    subscription = await get_group_subscription(
        user_id,
        group_id,
    )

    if not subscription:
        return False

    if subscription.get("status") != "active":
        return False

    expires_at = subscription.get(
        "expires_at"
    )

    if not expires_at:
        return False

    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(
            tzinfo=timezone.utc
        )
    else:
        expires_at = expires_at.astimezone(
            timezone.utc
        )

    if expires_at <= utc_now():
        await expire_group_subscription(
            user_id,
            group_id,
        )
        return False

    return True


# ============================================================
# EXPIRE
# ============================================================

async def expire_group_subscription(
    user_id: int,
    group_id: int,
) -> bool:
    """
    Expire one group's subscription.
    """

    result = await group_subscriptions().update_one(
        {
            "user_id": normalize_user_id(user_id),
            "group_id": normalize_group_id(group_id),
            "status": "active",
        },
        {
            "$set": {
                "status": "expired",
                "updated_at": utc_now(),
            }
        },
    )

    return result.modified_count > 0


# ============================================================
# CANCEL
# ============================================================

async def cancel_group_subscription(
    user_id: int,
    group_id: int,
) -> bool:
    """
    Cancel subscription for one exact group.
    """

    result = await group_subscriptions().update_one(
        {
            "user_id": normalize_user_id(user_id),
            "group_id": normalize_group_id(group_id),
            "status": "active",
        },
        {
            "$set": {
                "status": "cancelled",
                "cancelled_at": utc_now(),
                "updated_at": utc_now(),
            }
        },
    )

    return result.modified_count > 0


# ============================================================
# USER GROUP PLANS
# ============================================================

async def get_user_group_subscriptions(
    user_id: int,
    include_expired: bool = True,
) -> list[dict]:
    """
    Return all group subscriptions belonging to a user.

    Used by /myplan in Bot DM.
    """

    query = {
        "user_id": normalize_user_id(user_id),
    }

    if not include_expired:
        query["status"] = "active"

    cursor = group_subscriptions().find(
        query
    ).sort(
        "expires_at",
        1,
    )

    return await cursor.to_list(
        length=None
    )


# ============================================================
# CURRENT GROUP PLAN
# ============================================================

async def get_current_group_plan(
    user_id: int,
    group_id: int,
) -> dict:
    """
    Return clean plan information for /myplan
    used inside a group.
    """

    subscription = await get_group_subscription(
        user_id,
        group_id,
    )

    if not subscription:
        return {
            "active": False,
            "status": "none",
            "plan": "free",
            "group_id": int(group_id),
            "expires_at": None,
            "remaining_days": 0,
        }

    active = await is_group_subscription_active(
        user_id,
        group_id,
    )

    expires_at = subscription.get(
        "expires_at"
    )

    remaining_days = 0

    if expires_at and active:
        if expires_at.tzinfo is None:
            expires_at = expires_at.replace(
                tzinfo=timezone.utc
            )

        remaining_seconds = (
            expires_at - utc_now()
        ).total_seconds()

        if remaining_seconds > 0:
            remaining_days = max(
                1,
                int(
                    (remaining_seconds + 86399)
                    // 86400
                ),
            )

    return {
        "active": active,
        "status": (
            "active"
            if active
            else subscription.get(
                "status",
                "expired",
            )
        ),
        "plan": (
            subscription.get(
                "plan",
                PREMIUM_PLAN_NAME,
            )
            if active
            else "free"
        ),
        "group_id": int(group_id),
        "stars": subscription.get(
            "stars"
        ),
        "started_at": subscription.get(
            "started_at"
        ),
        "expires_at": expires_at,
        "remaining_days": remaining_days,
        "payment_id": subscription.get(
            "payment_id"
        ),
    }


# ============================================================
# PAYMENT → GROUP BINDING
# ============================================================

async def can_bind_payment_to_group(
    payment_id: str,
    user_id: int,
    group_id: int,
) -> tuple[bool, str]:
    """
    Check whether a paid payment can be attached
    to the requested group.

    This prevents one payment being reused for
    multiple groups.
    """

    from database.payments import get_payment

    payment = await get_payment(
        payment_id
    )

    if not payment:
        return False, "Payment not found."

    if payment.get("user_id") != int(user_id):
        return False, "This payment belongs to another user."

    if payment.get("status") != "paid":
        return False, "Payment is not completed."

    if payment.get("currency") != "XTR":
        return False, "Invalid payment currency."

    existing = await group_subscriptions().find_one(
        {
            "payment_id": payment_id,
        }
    )

    if existing:
        return False, "This payment is already used."

    existing_group = await get_group_subscription(
        user_id,
        group_id,
    )

    if existing_group and existing_group.get(
        "status"
    ) == "active":

        return False, (
            "This group already has an active subscription."
        )

    return True, "OK"


# ============================================================
# BIND PAYMENT TO GROUP
# ============================================================

async def activate_paid_group(
    payment_id: str,
    user_id: int,
    group_id: int,
) -> dict:
    """
    Bind a successfully paid payment to exactly one group.

    Payment must already be verified by Telegram.
    """

    allowed, reason = await can_bind_payment_to_group(
        payment_id,
        user_id,
        group_id,
    )

    if not allowed:
        raise ValueError(reason)

    from database.payments import get_payment

    payment = await get_payment(
        payment_id
    )

    if not payment:
        raise ValueError(
            "Payment not found."
        )

    duration_days = payment.get(
        "duration_days"
    ) or PREMIUM_DURATION_DAYS

    stars = payment.get(
        "amount"
    ) or PREMIUM_STARS_PRICE

    return await create_group_subscription(
        user_id=user_id,
        group_id=group_id,
        payment_id=payment_id,
        plan=payment.get(
            "plan"
        ) or PREMIUM_PLAN_NAME,
        duration_days=duration_days,
        stars=stars,
    )


# ============================================================
# EXPIRY PROCESSOR
# ============================================================

async def process_expired_group_subscriptions(
    limit: int = 100,
) -> int:
    """
    Mark expired group subscriptions as expired.
    """

    now = utc_now()

    cursor = group_subscriptions().find(
        {
            "status": "active",
            "expires_at": {
                "$lte": now,
            },
        }
    ).sort(
        "expires_at",
        1,
    ).limit(
        max(1, int(limit))
    )

    subscriptions = await cursor.to_list(
        length=max(1, int(limit))
    )

    processed = 0

    for subscription in subscriptions:
        result = await group_subscriptions().update_one(
            {
                "_id": subscription["_id"],
                "status": "active",
            },
            {
                "$set": {
                    "status": "expired",
                    "updated_at": utc_now(),
                }
            },
        )

        if result.modified_count:
            processed += 1

    return processed
