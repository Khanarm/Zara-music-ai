# payments/stars.py

import logging
import secrets
from typing import Optional

from aiogram import Bot, Router
from aiogram.types import (
    LabeledPrice,
    Message,
    PreCheckoutQuery,
)
from aiogram.filters import Command

from config import (
    PREMIUM_DURATION_DAYS,
    PREMIUM_PLAN_NAME,
    PREMIUM_STARS_PRICE,
    STARS_ENABLED,
    SUBSCRIPTIONS_ENABLED,
)

from database.payments import (
    create_payment,
    get_payment_by_payload,
    set_payment_status,
)

from payments.subscriptions import (
    activate_paid_group,
    initialize_subscription_indexes,
)

logger = logging.getLogger(__name__)

router = Router(
    name="zara_payments"
)


# ============================================================
# PAYMENT PAYLOAD
# ============================================================

def generate_payment_id() -> str:
    """
    Generate an internal unique payment ID.
    """

    return (
        "zara_"
        + secrets.token_urlsafe(18)
    )


def build_invoice_payload(
    payment_id: str,
) -> str:
    """
    Build Telegram invoice payload.
    """

    return f"zara-premium:{payment_id}"


def extract_payment_id(
    payload: str,
) -> Optional[str]:
    """
    Extract internal payment ID from invoice payload.
    """

    prefix = "zara-premium:"

    if not payload.startswith(prefix):
        return None

    payment_id = payload[
        len(prefix):
    ].strip()

    return payment_id or None


# ============================================================
# PAYMENT CONFIGURATION
# ============================================================

def payments_available() -> bool:
    return bool(
        STARS_ENABLED
        and SUBSCRIPTIONS_ENABLED
    )


def get_plan_price() -> int:
    """
    Always get the price from config.py.
    """

    return int(
        PREMIUM_STARS_PRICE
    )


def get_plan_duration() -> int:
    """
    Always get duration from config.py.
    """

    return int(
        PREMIUM_DURATION_DAYS
    )


# ============================================================
# CREATE INVOICE
# ============================================================

async def create_subscription_invoice(
    bot: Bot,
    user_id: int,
) -> Optional[str]:
    """
    Create and send the Telegram Stars invoice.

    Returns internal payment ID.
    """

    if not payments_available():
        raise RuntimeError(
            "Telegram Stars subscriptions are disabled."
        )

    user_id = int(user_id)

    payment_id = generate_payment_id()

    payload = build_invoice_payload(
        payment_id
    )

    price = get_plan_price()

    duration_days = get_plan_duration()

    # Create our own pending payment record BEFORE
    # sending the invoice.
    await create_payment(
        user_id=user_id,
        amount=price,
        currency="XTR",
        payment_provider="telegram_stars",
        payment_id=payment_id,
        invoice_payload=payload,
        plan=PREMIUM_PLAN_NAME,
        duration_days=duration_days,
        status="pending",
        metadata={
            "product": "zara_premium",
        },
    )

    await bot.send_invoice(
        chat_id=user_id,
        title=(
            f"{PREMIUM_PLAN_NAME} - "
            f"Zara AI"
        ),
        description=(
            "Activate Zara AI for one Telegram group "
            "for the configured subscription period."
        ),
        payload=payload,
        currency="XTR",
        prices=[
            LabeledPrice(
                label=(
                    f"{PREMIUM_PLAN_NAME} "
                    f"({duration_days} days)"
                ),
                amount=price,
            )
        ],
    )

    logger.info(
        "Stars invoice sent: user=%s payment=%s",
        user_id,
        payment_id,
    )

    return payment_id


# ============================================================
# PRE-CHECKOUT
# ============================================================

@router.pre_checkout_query()
async def pre_checkout_handler(
    query: PreCheckoutQuery,
) -> None:
    """
    Validate Telegram Stars checkout.

    Payment is NOT marked as paid here.
    Telegram's successful_payment event is authoritative.
    """

    try:
        payload = query.invoice_payload

        payment_id = extract_payment_id(
            payload
        )

        if not payment_id:
            await query.answer(
                ok=False,
                error_message=(
                    "Invalid Zara payment."
                ),
            )
            return

        payment = await get_payment_by_payload(
            payload
        )

        if not payment:
            await query.answer(
                ok=False,
                error_message=(
                    "Payment session expired or not found."
                ),
            )
            return

        if payment.get("status") != "pending":
            await query.answer(
                ok=False,
                error_message=(
                    "This payment is no longer available."
                ),
            )
            return

        expected_amount = int(
            payment.get(
                "amount",
                0,
            )
        )

        if int(
            query.total_amount
        ) != expected_amount:

            await query.answer(
                ok=False,
                error_message=(
                    "Payment amount mismatch."
                ),
            )
            return

        await query.answer(
            ok=True
        )

    except Exception:
        logger.exception(
            "Pre-checkout validation failed."
        )

        await query.answer(
            ok=False,
            error_message=(
                "Unable to verify payment."
            ),
        )


# ============================================================
# SUCCESSFUL PAYMENT
# ============================================================

@router.message()
async def successful_payment_handler(
    message: Message,
) -> None:
    """
    Handle Telegram successful Stars payment.

    This handler intentionally checks only messages
    containing successful_payment.
    """

    payment = message.successful_payment

    if not payment:
        return

    if not message.from_user:
        return

    user_id = int(
        message.from_user.id
    )

    payload = payment.invoice_payload

    payment_id = extract_payment_id(
        payload
    )

    if not payment_id:
        logger.error(
            "Successful payment has invalid payload: %s",
            payload,
        )
        return

    try:
        stored_payment = await get_payment_by_payload(
            payload
        )

        if not stored_payment:
            logger.error(
                "Payment record not found for payload %s",
                payload,
            )
            return

        # Prevent replay/duplicate processing.
        if stored_payment.get(
            "status"
        ) == "paid":

            await message.answer(
                "⚠️ This payment has already been processed."
            )
            return

        # Security checks.
        if int(
            stored_payment.get(
                "user_id"
            )
        ) != user_id:

            logger.error(
                "Payment user mismatch: payment=%s user=%s",
                payment_id,
                user_id,
            )
            return

        if payment.currency != "XTR":
            logger.error(
                "Invalid Stars currency: %s",
                payment.currency,
            )
            return

        if int(
            payment.total_amount
        ) != int(
            stored_payment.get(
                "amount",
                0,
            )
        ):

            logger.error(
                "Payment amount mismatch: %s",
                payment_id,
            )
            return

        # Mark the payment as paid ONLY after Telegram
        # confirms successful_payment.
        updated = await set_payment_status(
            payment_id,
            "paid",
        )

        if not updated:
            # It may already have been updated by a race.
            stored_payment = await get_payment_by_payload(
                payload
            )

            if not stored_payment or stored_payment.get(
                "status"
            ) != "paid":

                raise RuntimeError(
                    "Unable to mark payment as paid."
                )

        await set_payment_status(
            payment_id,
            "paid",
        )

        # Save Telegram's authoritative charge ID and
        # other payment information.
        from database.payments import update_payment

        await update_payment(
            payment_id,
            telegram_payment_charge_id=(
                payment.telegram_payment_charge_id
            ),
            provider_payment_charge_id=(
                getattr(
                    payment,
                    "provider_payment_charge_id",
                    None,
                )
            ),
            paid_amount=payment.total_amount,
            paid_currency=payment.currency,
        )

        logger.info(
            "Telegram Stars payment verified: "
            "user=%s payment=%s",
            user_id,
            payment_id,
        )

        await message.answer(
            "✅ <b>Payment successful!</b>\n\n"
            "Your Zara subscription payment has been "
            "verified.\n\n"
            "Now send me the <b>Group ID</b> where "
            "you want to activate Zara.\n\n"
            "Example:\n"
            "<code>-1001234567890</code>\n\n"
            "⚠️ Make sure Zara's bot is already added "
            "to that group."
        )

    except Exception:
        logger.exception(
            "Successful Stars payment processing failed."
        )

        await message.answer(
            "⚠️ Payment was received, but I could not "
            "finish activation automatically.\n\n"
            "Please contact the owner."
        )


# ============================================================
# GROUP ID ACTIVATION
# ============================================================

async def activate_payment_for_group(
    user_id: int,
    payment_id: str,
    group_id: int,
) -> dict:
    """
    Bind a verified paid payment to one group.

    The caller should verify that the user and bot
    actually belong to the group before calling this.
    """

    return await activate_paid_group(
        payment_id=payment_id,
        user_id=user_id,
        group_id=group_id,
    )


# ============================================================
# INITIALIZATION
# ============================================================

async def initialize_payment_layer() -> None:
    """
    Initialize indexes required by the payment/subscription layer.
    """

    if not payments_available():
        logger.info(
            "Zara Stars subscriptions are disabled."
        )
        return

    await initialize_subscription_indexes()

    logger.info(
        "Zara payment/subscription layer initialized."
    )


# ============================================================
# ROUTER REGISTRATION
# ============================================================

def register_payment_handlers(
    dispatcher,
) -> None:
    """
    Register Telegram Stars payment handlers.
    """

    dispatcher.include_router(
        router
    )

    logger.info(
        "Zara payment handlers registered."
)
