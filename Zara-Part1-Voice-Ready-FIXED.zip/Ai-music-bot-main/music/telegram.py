import logging
from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from config import OWNER_ID
from music.service import MusicService
logger=logging.getLogger(__name__)
router=Router()
_service: MusicService|None=None

def configure(service):
    global _service; _service=service

def svc():
    if _service is None: raise RuntimeError('Music service is not initialized')
    return _service

@router.message(Command('join'))
async def join_cmd(message: Message):
    if not message.from_user:return
    if not await svc().is_admin(message.chat.id,message.from_user.id):
        await message.answer('🚫 Sirf group admin/owner /join use kar sakta hai.'); return
    await svc().join(message.chat.id)

@router.message(Command('end'))
async def end_cmd(message: Message):
    if not message.from_user:return
    if not await svc().is_admin(message.chat.id,message.from_user.id):
        await message.answer('🚫 Sirf group admin/owner /end use kar sakta hai.'); return
    await svc().end(message.chat.id)

@router.message(Command('use'))
async def use_cmd(message: Message):
    if not message.from_user:return
    if int(message.from_user.id)!=int(OWNER_ID):
        await message.answer('🚫 Sirf Zara owner /use change kar sakta hai.'); return
    kb=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text='👥 All User',callback_data=f'music_mode:all:{message.chat.id}'),InlineKeyboardButton(text='👑 Admin',callback_data=f'music_mode:admin:{message.chat.id}')]])
    await message.answer('🎛️ <b>Music Request Mode</b>\nChoose who can request songs:',reply_markup=kb)

@router.callback_query(F.data.startswith('music_mode:'))
async def mode_callback(callback: CallbackQuery):
    if not callback.from_user:return
    if int(callback.from_user.id)!=int(OWNER_ID): await callback.answer('Owner only.',show_alert=True); return
    _,mode,chat_id=callback.data.split(':',2)
    await svc().set_mode(int(chat_id),mode)
    await callback.answer('Mode updated.')
    await callback.message.edit_text(f'✅ Music request mode: <b>{"All users" if mode=="all" else "Admins only"}</b>')


__all__=["router","configure"]
