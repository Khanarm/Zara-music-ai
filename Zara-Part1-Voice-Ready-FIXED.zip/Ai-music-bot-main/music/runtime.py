import logging
from pytgcalls import PyTgCalls
from telegram.client import get_user_client, get_bot
from audio.stream import AudioStream
from music.service import MusicService
from music.telegram import configure as configure_router
from voice.music_commands import configure_music_service
logger=logging.getLogger(__name__)
_calls=None; _stream=None; _service=None
async def start_music():
 global _calls,_stream,_service
 user=get_user_client(); bot=get_bot()
 _calls=PyTgCalls(user)
 _stream=AudioStream(user,_calls)
 await _stream.start()
 _service=MusicService(_stream,bot)
 configure_router(_service); configure_music_service(_service)
 logger.info('Music runtime started')
 return _service
async def stop_music():
 global _calls,_stream,_service
 if _stream:
  await _stream.cleanup()
 _calls=None; _stream=None; _service=None

def get_music_service(): return _service
