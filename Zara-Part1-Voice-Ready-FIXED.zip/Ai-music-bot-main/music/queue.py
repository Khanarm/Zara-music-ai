import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional
from config import MUSIC_MAX_QUEUE
logger=logging.getLogger(__name__)
def utc_now(): return datetime.now(timezone.utc)
@dataclass
class Track:
    title:str; url:Optional[str]=None; audio_url:Optional[str]=None; audio_path:Optional[str]=None; duration:Optional[int]=None; requested_by:Optional[int]=None; requested_by_name:Optional[str]=None; thumbnail:Optional[str]=None; source:Optional[str]=None; metadata:dict[str,Any]=field(default_factory=dict); added_at:datetime=field(default_factory=utc_now)
    def to_dict(self): return self.__dict__.copy()
QUEUE:dict[int,list[Track]]={}
def add_to_queue(chat_id,track):
    q=QUEUE.setdefault(int(chat_id),[])
    if len(q)>=MUSIC_MAX_QUEUE: raise OverflowError('queue full')
    q.append(track); return len(q)
def get_queue(chat_id): return list(QUEUE.get(int(chat_id),[]))
def get_next(chat_id): q=QUEUE.get(int(chat_id),[]); return q[0] if q else None
def pop_next(chat_id):
    q=QUEUE.get(int(chat_id),[])
    if not q:return None
    x=q.pop(0)
    if not q:QUEUE.pop(int(chat_id),None)
    return x
def clear_queue(chat_id): QUEUE.pop(int(chat_id),None)
def remove_from_queue(chat_id,index):
    q=QUEUE.get(int(chat_id),[])
    if index<1 or index>len(q):return None
    return q.pop(index-1)
def queue_size(chat_id):return len(QUEUE.get(int(chat_id),[]))
def is_queue_empty(chat_id):return not bool(QUEUE.get(int(chat_id),[]))
