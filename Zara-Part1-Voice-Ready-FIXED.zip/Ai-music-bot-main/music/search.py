import asyncio, logging, re
from dataclasses import dataclass, field
from typing import Any, Optional
import yt_dlp
from youtubesearchpython.__future__ import VideosSearch
logger=logging.getLogger(__name__)
@dataclass
class SearchResult:
    title:str; url:Optional[str]=None; audio_url:Optional[str]=None; duration:Optional[int]=None; thumbnail:Optional[str]=None; source:str='youtube'; metadata:dict[str,Any]=field(default_factory=dict)
    def to_dict(self): return self.__dict__.copy()
class MusicSearcher:
    async def search(self, query:str, limit:int=5):
        q=str(query or '').strip()
        if not q:return []
        def run(): return VideosSearch(q,limit=max(1,min(int(limit),10))).result().get('result',[])
        try:
            rows=await asyncio.to_thread(run)
        except Exception:
            logger.exception('YouTube search failed'); return []
        out=[]
        for r in rows:
            out.append(SearchResult(title=r.get('title','Unknown'),url=r.get('link'),duration=self._duration(r.get('duration')),thumbnail=r.get('thumbnails',[{}])[0].get('url') if r.get('thumbnails') else None,metadata={'video_id':r.get('id')}))
        return out
    def _duration(self,s):
        if not s:return None
        try:
            p=[int(x) for x in str(s).split(':')]
            return p[-1]+(p[-2]*60 if len(p)>1 else 0)+(p[-3]*3600 if len(p)>2 else 0)
        except:return None
    async def first(self,q):
        r=await self.search(q,1); return r[0] if r else None
