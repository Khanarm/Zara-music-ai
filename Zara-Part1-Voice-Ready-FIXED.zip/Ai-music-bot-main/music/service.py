import asyncio
import logging
from dataclasses import dataclass
from typing import Optional

from config import MUSIC_MAX_QUEUE, OWNER_ID
from music.queue import Track, add_to_queue, clear_queue, get_queue, pop_next
from music.search import MusicSearcher
from music.downloader import MusicDownloader

logger = logging.getLogger(__name__)

@dataclass
class MusicPolicy:
    mode: str = "all"

@dataclass
class PlayerSession:
    chat_id: int
    current: Optional[Track] = None
    paused: bool = False
    loop: bool = False
    joined: bool = False
    playing: bool = False
    controller_id: Optional[int] = None
    controller_name: Optional[str] = None

class MusicService:
    def __init__(self, audio_stream, bot=None):
        self.audio = audio_stream
        self.bot = bot
        self.searcher = MusicSearcher()
        self.downloader = MusicDownloader()
        self.sessions: dict[int, PlayerSession] = {}
        self.policies: dict[int, MusicPolicy] = {}
        self.locks: dict[int, asyncio.Lock] = {}
        self.auto_tasks: dict[int, asyncio.Task] = {}

    def _lock(self, chat_id):
        return self.locks.setdefault(int(chat_id), asyncio.Lock())

    def session(self, chat_id):
        return self.sessions.setdefault(int(chat_id), PlayerSession(int(chat_id)))

    def policy(self, chat_id):
        return self.policies.setdefault(int(chat_id), MusicPolicy())

    async def is_admin(self, chat_id, user_id):
        if int(user_id) == int(OWNER_ID): return True
        if not self.bot: return False
        try:
            m = await self.bot.get_chat_member(int(chat_id), int(user_id))
            return str(m.status) in {"creator", "administrator"}
        except Exception:
            return False

    async def can_request(self, chat_id, user_id):
        return self.policy(chat_id).mode == "all" or await self.is_admin(chat_id, user_id)

    async def can_control(self, chat_id, user_id):
        s = self.session(chat_id)
        return await self.is_admin(chat_id, user_id) or (s.controller_id is not None and int(s.controller_id) == int(user_id))

    async def announce(self, chat_id, text):
        if not self.bot: return
        try: await self.bot.send_message(int(chat_id), text)
        except Exception: logger.exception("music announcement failed")

    async def join(self, chat_id):
        self.session(chat_id).joined = True
        await self.announce(chat_id, "🎧 <b>Zara music mode ready.</b>\nVoice request bhejo.")
        return True

    async def end(self, chat_id):
        task = self.auto_tasks.pop(int(chat_id), None)
        if task and not task.done(): task.cancel()
        try: await self.audio.stop(int(chat_id))
        except Exception: pass
        clear_queue(chat_id)
        self.sessions.pop(int(chat_id), None)
        await self.announce(chat_id, "⛔ <b>Zara left the voice chat.</b>")
        return True

    async def request(self, chat_id, user_id, user_name, query, video=False):
        if not await self.can_request(chat_id, user_id):
            return False, "🚫 Admin mode active hai. Sirf group admin/owner song request kar sakta hai."
        query = str(query or '').strip()
        if not query: return False, "🎵 Song name batao."
        if len(get_queue(chat_id)) >= int(MUSIC_MAX_QUEUE): return False, "⚠️ Queue full hai."
        result = await self.searcher.first(query)
        if not result: return False, "❌ Song nahi mila."
        track = Track(title=result.title, url=result.url, duration=result.duration, thumbnail=result.thumbnail,
                      requested_by=int(user_id), requested_by_name=user_name, source='youtube',
                      metadata={'video': bool(video), 'search_query': query})
        position = add_to_queue(chat_id, track)
        s = self.session(chat_id)
        if s.current is None and not s.playing:
            await self.announce(chat_id, f"🎵 <b>{user_name}</b> ne <b>{track.title}</b> request kiya.\n▶️ Ab play ho raha hai.")
            ok = await self._play_next(chat_id)
            if not ok: return False, "❌ Song play nahi ho saka."
            return True, None
        await self.announce(chat_id, f"📥 <b>{user_name}</b> ne <b>{track.title}</b> request kiya.\n⏭️ Ye queue me <b>#{position}</b> par hai.")
        return True, None

    async def _prepare(self, track):
        path = await self.downloader.download(track, video=bool(track.metadata.get('video')))
        if not path: return None
        track.audio_path = path
        return path

    def _schedule_auto_next(self, chat_id, duration):
        old = self.auto_tasks.pop(int(chat_id), None)
        if old and not old.done(): old.cancel()
        if not duration or duration <= 0: return
        async def waiter():
            try:
                await asyncio.sleep(int(duration) + 2)
                s = self.session(chat_id)
                if s.current and s.playing and not s.paused:
                    await self._play_next(chat_id)
                    n = self.session(chat_id).current
                    if n:
                        await self.announce(chat_id, f"▶️ <b>Next song:</b> {n.title}\n👤 Requested by: <b>{n.requested_by_name or 'Unknown'}</b>")
            except asyncio.CancelledError: pass
            except Exception: logger.exception('auto-next failed')
        self.auto_tasks[int(chat_id)] = asyncio.create_task(waiter())

    async def _play_next(self, chat_id):
        async with self._lock(chat_id):
            s = self.session(chat_id)
            if s.loop and s.current:
                path = await self._prepare(s.current)
                if not path: return False
                ok = await self.audio.play(chat_id, path, video=bool(s.current.metadata.get('video')))
                s.playing, s.paused, s.joined = ok, False, True
                if ok: self._schedule_auto_next(chat_id, s.current.duration)
                return ok
            while True:
                track = pop_next(chat_id)
                if track is None:
                    s.current=None; s.playing=False; s.paused=False; s.controller_id=None; s.controller_name=None
                    return False
                path = await self._prepare(track)
                if not path: continue
                ok = await self.audio.play(chat_id, path, video=bool(track.metadata.get('video')))
                if not ok: continue
                s.current=track; s.playing=True; s.paused=False; s.joined=True
                s.controller_id=track.requested_by; s.controller_name=track.requested_by_name
                self._schedule_auto_next(chat_id, track.duration)
                return True

    async def skip(self, chat_id, user_id):
        if not await self.can_control(chat_id, user_id): return False, "🚫 Sirf current requester ya group admin/owner skip kar sakta hai."
        s=self.session(chat_id); old=s.current.title if s.current else 'current song'
        task=self.auto_tasks.pop(int(chat_id),None)
        if task and not task.done(): task.cancel()
        await self.audio.stop(chat_id); s.playing=False
        ok=await self._play_next(chat_id)
        if ok:
            n=self.session(chat_id).current
            await self.announce(chat_id, f"⏭️ <b>{old}</b> skipped.\n▶️ <b>{n.title}</b> — 👤 <b>{n.requested_by_name or 'Unknown'}</b>")
            return True,None
        await self.announce(chat_id,"⏭️ Song skipped. Queue empty hai.")
        return True,None

    async def pause(self, chat_id, user_id):
        if not await self.can_control(chat_id,user_id): return False,"🚫 Sirf current requester ya group admin/owner pause kar sakta hai."
        ok=await self.audio.pause(chat_id)
        if ok:
            s=self.session(chat_id); s.paused=True; s.playing=False
            task=self.auto_tasks.pop(int(chat_id),None)
            if task and not task.done(): task.cancel()
            await self.announce(chat_id,"⏸️ Music paused."); return True,None
        return False,"⚠️ Installed PyTgCalls version native pause support nahi deti."

    async def resume(self, chat_id, user_id):
        if not await self.can_control(chat_id,user_id): return False,"🚫 Sirf current requester ya group admin/owner resume kar sakta hai."
        ok=await self.audio.resume(chat_id)
        if ok:
            s=self.session(chat_id); s.paused=False; s.playing=True; self._schedule_auto_next(chat_id,s.current.duration if s.current else None)
            await self.announce(chat_id,"▶️ Music resumed."); return True,None
        return False,"⚠️ Resume available nahi hai."

    async def stop(self, chat_id, user_id):
        if not await self.can_control(chat_id,user_id): return False,"🚫 Sirf current requester ya group admin/owner stop kar sakta hai."
        task=self.auto_tasks.pop(int(chat_id),None)
        if task and not task.done(): task.cancel()
        await self.audio.stop(chat_id); clear_queue(chat_id); self.sessions.pop(int(chat_id),None)
        await self.announce(chat_id,"⛔ Music stopped aur queue clear kar di gayi."); return True,None

    async def toggle_loop(self, chat_id, user_id):
        if not await self.can_control(chat_id,user_id): return False,"🚫 Sirf current requester ya group admin/owner loop change kar sakta hai."
        s=self.session(chat_id); s.loop=not s.loop; return True,f"🔁 Loop {'ON' if s.loop else 'OFF'}."

    def queue_text(self, chat_id):
        s=self.session(chat_id); q=get_queue(chat_id); lines=['🎵 <b>Zara Queue</b>']
        if s.current: lines.append(f"▶️ {s.current.title}\n👤 {s.current.requested_by_name or 'Unknown'}")
        for i,t in enumerate(q,1): lines.append(f"{i}. {t.title} — 👤 {t.requested_by_name or 'Unknown'}")
        if not q: lines.append('📭 Next queue empty.')
        return '\n'.join(lines)

    async def handle_text(self, chat_id, user_id, user_name, text):
        t=str(text or '').lower().strip()
        if any(x in t for x in ['pause','pous','paus']): return await self.pause(chat_id,user_id)
        if any(x in t for x in ['resume','continue','phir chala']): return await self.resume(chat_id,user_id)
        if any(x in t for x in ['skip','next song','next','agla song']): return await self.skip(chat_id,user_id)
        if any(x in t for x in ['stop music','stop song','music stop','song band']): return await self.stop(chat_id,user_id)
        if 'queue' in t or 'playlist' in t: return True,self.queue_text(chat_id)
        if 'loop' in t: return await self.toggle_loop(chat_id,user_id)
        q=t
        for phrase in ['zara','song play karo','song play kro','song sunao','gana sunao','gaana sunao','music play karo','music chalao','play karo','bajao','chalao']:
            q=q.replace(phrase,' ')
        return await self.request(chat_id,user_id,user_name,' '.join(q.split()))
