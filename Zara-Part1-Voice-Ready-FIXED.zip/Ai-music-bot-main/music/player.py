# PyTgCalls player logic
