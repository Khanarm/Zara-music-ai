import asyncio, logging, os, re
from pathlib import Path
from typing import Any, Optional
import yt_dlp
from config import MUSIC_DOWNLOAD_DIR, MUSIC_MAX_FILE_SIZE_MB
logger = logging.getLogger(__name__)

class MusicDownloader:
    def __init__(self, download_dir=None, max_file_size_mb=None):
        self.download_dir=Path(download_dir or MUSIC_DOWNLOAD_DIR); self.download_dir.mkdir(parents=True,exist_ok=True)
        self.max_bytes=int(max_file_size_mb or MUSIC_MAX_FILE_SIZE_MB)*1024*1024
    def _name(self,s): return re.sub(r'[\\/:*?"<>|]+','_',str(s or 'audio')).strip()[:150]
    async def download(self, track: Any, video=False)->Optional[str]:
        url=track.get('url') if isinstance(track,dict) else getattr(track,'url',None)
        title=track.get('title','audio') if isinstance(track,dict) else getattr(track,'title','audio')
        if not url: return None
        out=self.download_dir / f"%(id)s.%(ext)s"
        cookies=os.getenv('YOUTUBE_COOKIES_FILE','').strip()
        opts={'quiet':True,'no_warnings':True,'noplaylist':True,'outtmpl':str(out),'overwrites':False,'restrictfilenames':True}
        opts['format']= 'bestvideo[height<=720]+bestaudio/best[height<=720]' if video else 'bestaudio/best'
        if cookies and Path(cookies).is_file(): opts['cookiefile']=cookies
        def run():
            with yt_dlp.YoutubeDL(opts) as ydl:
                info=ydl.extract_info(url,download=True)
                path=ydl.prepare_filename(info)
                # merged output may be mp4/webm; locate by id if extension changed
                p=Path(path)
                if not p.exists():
                    for c in self.download_dir.glob(f"{info.get('id','')}.*"):
                        if c.is_file(): p=c; break
                return str(p) if p.exists() else None
        try:
            path=await asyncio.to_thread(run)
            if path and Path(path).stat().st_size<=self.max_bytes: return path
            if path: Path(path).unlink(missing_ok=True)
        except Exception: logger.exception('yt-dlp download failed for %s',title)
        return None
