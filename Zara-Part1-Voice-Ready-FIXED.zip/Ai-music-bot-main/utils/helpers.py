# General helpers
